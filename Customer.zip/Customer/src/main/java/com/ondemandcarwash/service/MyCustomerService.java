package com.ondemandcarwash.service;

public class MyCustomerService  {

}
